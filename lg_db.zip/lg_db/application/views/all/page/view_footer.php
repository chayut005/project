			<style>
				.foo{
					font-size:12px;
					color:white;
					text-align:center;
				}
			</style>
			<div class="footer">
				<div class="footer-inner">
					<!-- <div class="footer-content"> -->
						<!-- <div class="col-xs-12 col-sm-6"> -->
						<span class="bigger-120">
							<span class="foo" style="padding: 20px;"><a href="#">© TBK Group Company.</a></span>			
						</span>
				</div>
			</div>
