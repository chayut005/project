define( function() {} );
